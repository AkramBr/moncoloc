<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-md-offset-2">
                <h2 class="col-md-offset-1">Les Offres</h2><br>
                <form action="/publish" method="post" enctype="multipart/form-data">
                    <div class="form-group col-md-9">
                        <?php echo e(csrf_field()); ?>


                                <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myoffer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                          
                            
                            <!--<div class="panel panel-default">
                                <div class="panel-heading">Adresse:</div>
                                <div class="panel-body"><?php echo e($myoffer->adresse); ?></div>
                            </div>
                        
                            <div class="panel panel-default">
                                <div class="panel-heading">Prix</div>
                                <div class="panel-body"><?php echo e($myoffer->prix); ?><span>Dinar</span>
                                <div class="pull-right">
                                <a href="offerdetails/<?php echo e($myoffer->id); ?>">View</a>
                            </div></div>
                            </div>-->
                            
                             <table class="table table-hover">
                              
                                <tbody>
                                  <tr>
                                    <td class="col-md-4"><?php echo e($myoffer->adresse); ?></td>
                                    <td class="col-md-4">Price: <?php echo e($myoffer->prix); ?></td>
                                    <td class="text-right"><a href="offerdetails/<?php echo e($myoffer->id); ?>">View</a></td>
                                  </tr>
                            
                                </tbody>
                              </table>


                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>







                    </div>
                </form>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>