<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-2">
                <h2 style="padding-left: 50px;">Details</h2><br>
                <form action="/publish" method="post" enctype="multipart/form-data">
                    <div class="form-group col-md-9">
                        <?php echo e(csrf_field()); ?>


                            

                            <div class="panel panel-default">
                                <div class="panel-heading">Adresse:</div>
                                <div class="panel-body"><?php echo e($offers->adresse); ?></div>
                            </div>
                            <div class="panel panel-default ">
                                <div class="panel-heading ">Type</div>
                                <div class="panel-body"><?php echo e($offers->type); ?></div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading">Prix</div>
                                <div class="panel-body"><?php echo e($offers->prix); ?><span>Dinar</span></div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading">Description</div>
                                <div class="panel-body"><?php echo e($offers->description); ?></div>
                            </div>

                            <div class="fb-share-button" data-href="http://localhost:8000/offerdetails/" data-layout="button_count" data-size="large" data-mobile-iframe="false"><a class="fb-xfbml-parse-ignore" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Flocalhost%3A8000%2Fofferdetails%2F&amp;src=sdkpreparse">Partager</a></div>
               







                    </div>
                </form>

            </div>
        </div>
    </div>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/fr_FR/sdk.js#xfbml=1&version=v2.8";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>