@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-md-10 col-md-offset-2">
                <h2 style="padding-left: 50px;">Publier une offre</h2><br>

                <form action="publish" method="post">

                    <div class="form-group col-md-9">

                        {{ csrf_field() }}

                        <label for="adresse">Adresse:</label><br>
                        <input type="text" class="form-control" name="adresse">

                        <label for="type">type:</label>
                        <select class="form-control" name="type">
                            <option>Appartement</option>
                            <option>Villa</option>
                            <option>Studio</option>
                        </select>
                        <label for="prix">Prix:</label><br>
                        <input type="text" class="form-control" name="prix">
                        <label for="adresse">Description</label><br>
                        <textarea class="form-control" name="description" rows="6">
                        </textarea><br>
                        <input type="submit" class="pull-right btn btn-sm btn-primary">





                    </div>
                </form>

            </div>
        </div>
    </div>
@endsection
