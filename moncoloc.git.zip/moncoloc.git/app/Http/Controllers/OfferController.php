<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Offer;


class OfferController extends Controller
{
    public function viewoffers(){


        $offers = Offer::all();
        $array= array('offers'=>$offers);
        return view('offers', $array);
    }

    public function AddOffer (Request $request){


        if ($request->isMethod('post')){
            $newoffer =new Offer();
            $newoffer->adresse=$request->input('adresse');
            $newoffer->type=$request->input('type');
            $newoffer->prix=$request->input('prix');
            $newoffer->description=$request->input('description');

            $newoffer->save();
        }
        return view('publish');

    }
    
    public function ViewDetails ( Request $request, $id){
        
                $offers = Offer::find($id);
                $arr = array ('offers'=>$offers);
                return view('offerdetails',$arr);
    }
}
